<?php // this is what I removed from the raw_html.php file
/*****************************************************
	Disable default formatting on a per-post level
******************************************************/

//Apply function $func to $content unless it's been disabled for the current post 
function maybe_use_filter($func, $content){
	global $post;
	if (get_post_meta($post->ID, 'disable_'.$func, true) == '1') {
		return $content;
	} else {
		return $func($content);
	}
}

//Stub filters that replace the WP defaults
function maybe_wptexturize($content){
	return maybe_use_filter('wptexturize', $content);
}

function maybe_wpautop($content){
	return maybe_use_filter('wpautop', $content);
}

function maybe_convert_chars($content){
	return maybe_use_filter('convert_chars', $content);
}

function maybe_convert_smilies($content){
	return maybe_use_filter('convert_smilies', $content);
}

// Disable default filters and add our conditional filters
function rawhtml_add_conditional_filters(){
	$filters = array(
		'the_content' => array(
			'wpautop',
			'wptexturize',
			'convert_chars',
			'convert_smilies',
		),
		'the_excerpt' => array(
			'wpautop',
			'wptexturize',
			'convert_chars',
			'convert_smilies',
		),
	);
	
	foreach ( $filters as $tag => $functions ){
		foreach ( $functions as $func ){
			if ( remove_filter($tag, $func) ){
				add_filter( $tag, 'maybe_'.$func, 3 );
			};
		}
	}
}
add_action('init', 'rawhtml_add_conditional_filters');

// Add a custom meta box for per-post settings 
add_action('admin_menu', 'rawhtml_add_custom_box');
add_action('save_post', 'rawhtml_save_postdata');

/* Adds a custom section to the "advanced" Post and Page edit screens */
function rawhtml_add_custom_box() {
  //WP 2.5+
  if( function_exists( 'add_meta_box' )) { 
  	foreach( array('post', 'page') as $type ) {
	    add_meta_box( 'rawhtml_meta_box', 'Raw HTML', 'rawhtml_meta_box', $type, 'side' );
    }
  }
}

/* Displays the custom box */
function rawhtml_meta_box(){
	global $post;
	// Use nonce for verification
	echo '<input type="hidden" name="rawhtml_nonce" id="rawhtml_nonce" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
	
	//Output checkboxes 
	$fields = array(
		'disable_wptexturize' => 'Disable wptexturize',
		'disable_wpautop' => 'Disable automatic paragraphs',
		'disable_convert_chars' => 'Disable convert_chars',
		'disable_convert_smilies' => 'Disable smilies',
	);
	$defaults = rawhtml_get_default_settings();
	foreach($fields as $field => $legend){
		$current_setting = get_post_meta($post->ID, $field, true);
		if ( $current_setting == '' ){
			$current_setting = $defaults[$field];
		} else {
			$current_setting = (bool)intval($current_setting);
		}
?>
<label for="rawhtml_<?php echo $field; ?>">
	<input type="checkbox" name="rawhtml_<?php echo $field; ?>" id="rawhtml_<?php echo $field; ?>" <?php
		if ($current_setting) echo ' checked="checked"';
	?>/>
	<?php echo $legend; ?>
</label>
<br /> 
<?php
	}
}

/* Saves post metadata */
function rawhtml_save_postdata( $post_id ){
  // verify this came from the our screen and with proper authorization,
  // because save_post can be triggered at other times
  
  if ( !isset($_POST['rawhtml_nonce']) ){
	return $post_id;
  }
  
  if ( !wp_verify_nonce( $_POST['rawhtml_nonce'], plugin_basename(__FILE__) )) {
    return $post_id;
  }

  if ( 'page' == $_POST['post_type'] ) {
    if ( !current_user_can( 'edit_page', $post_id ))
      return $post_id;
  } else {
    if ( !current_user_can( 'edit_post', $post_id ))
      return $post_id;
  }
  
  // OK, we're authenticated: we need to find and save the data
  $fields  = array('disable_wpautop', 'disable_wptexturize', 'disable_convert_chars', 'disable_convert_smilies');
  foreach ( $fields as $field ){	
  	  if ( !empty($_POST['rawhtml_'.$field]) ){
		update_post_meta($post_id, $field, '1');
	  } else {
		update_post_meta($post_id, $field, '0');
	  };
  }

  return true;
}

//Add our panel to the "Screen Options" box
add_screen_options_panel(
	'rawhtml-default-settings', 
	'Raw HTML defaults', 
	'rawhtml_default_settings_panel', 
	array('post', 'page'),
	'rawhtml_save_new_defaults',
	true
);

/**
 * Retrieve the default settings for our post/page meta box.
 * Settings are saved in user meta.
 * 
 * @return array
 */
function rawhtml_get_default_settings(){
	//By default, all tweaks are disabled
	$defaults = array(
		'disable_wptexturize' => false,
		'disable_wpautop' => false,
		'disable_convert_chars' => false,
		'disable_convert_smilies' => false,
	);
	
	if ( !function_exists('wp_get_current_user') || !function_exists('get_user_meta') ){
		return $defaults;
	}
	
	//Get current defaults, if any
	$user = wp_get_current_user();
	$user_defaults = get_user_meta($user->ID, 'rawhtml_defaults', true);
	if ( is_array($user_defaults) ){
		$defaults = array_merge($defaults, $user_defaults);
	}
	
	return $defaults;
}

/**
 * Update default settings for our post/page meta box.
 * 
 * @param array $new_defaults
 * @return bool True on success, false on failure.
 */
function rawhtml_set_default_settings($new_defaults){
	if ( !function_exists('wp_get_current_user') || !function_exists('update_user_meta') ){
		return false;
	}
	
	//Get current defaults, if any
	$user = wp_get_current_user();
	if ( isset($user) && $user && isset($user->ID) ){
		return update_user_meta($user->ID, 'rawhtml_defaults', $new_defaults);
	} else {
		return false;
	}
}

/**
 * Generate the "Raw HTML defaults" panel for Screen Options.
 * 
 * @return string
 */
function rawhtml_default_settings_panel(){
	$defaults = rawhtml_get_default_settings();
	
	//Output checkboxes 
	$fields = array(
		'disable_wptexturize' => 'Disable wptexturize',
		'disable_wpautop' => 'Disable automatic paragraphs',
		'disable_convert_chars' => 'Disable convert_chars',
		'disable_convert_smilies' => 'Disable smilies',
	 );
	 
 	$output = '';
	foreach($fields as $field => $legend){
		$esc_field = esc_attr($field);
		$output .= sprintf(
			'<label for="rawhtml_default-%s" style="line-height: 20px;">
				<input type="checkbox" name="rawhtml_default-%s" id="rawhtml_default-%s"%s>
				%s
			</label><br>',
			$esc_field,
			$esc_field,
			$esc_field,
			($defaults[$field]?' checked="checked"':''),
			$legend
		);
	}
	
	return $output;
}

/**
 * Process the "Raw HTML defaults" form fields and save new settings
 * 
 * @param array $params
 * @return void
 */
function rawhtml_save_new_defaults($params){
	//Get current defaults
	$defaults = rawhtml_get_default_settings();
	
	//Read new values from the submitted form
	foreach($defaults as $field => $old_value){
		if ( isset($params['rawhtml_default-'.$field]) && ($params['rawhtml_default-'.$field] == 'on') ){
			$defaults[$field] = true;
		} else {
			$defaults[$field] = false;
		}
	}
	
	//Store the new defaults
	rawhtml_set_default_settings($defaults);
}
?>